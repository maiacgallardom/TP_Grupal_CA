#!/bin/bash
set -euo pipefail

show_help() {
  cat << 'EOF'
Uso: backup_full.sh <origen> <destino>
Hace un backup .tar.gz del <origen> en <destino> con fecha YYYYMMDD.
Ejemplos:
  backup_full.sh /var/log /backup_dir
  backup_full.sh /www_dir /backup_dir
Opciones:
  -help   Muestra esta ayuda
Notas:
  * Verifica que <destino> sea un punto de montaje valido y escribible.
  * El nombre de salida es <basename_origen>_bkp_YYYYMMDD.tar.gz
EOF
}

# --- argumentos /ayuda ---
if [[ "${1:-}" == "-help" || "${1:-}" == "--help" ]]; then
  show_help; exit 0
fi
if [[ $# -ne 2 ]]; then
  echo "Error: se esperan 2 argumentos. Proba -help." >&2
  exit 1
fi


ORIG="$1"
DEST="$2"

# ---validaciones ---
# 1) Origen existe y es legible
if [[ ! -d "$ORIG" ]]; then
  echo "Error: origen '$ORIG' no existe o no es directorio." >&2
  exit 2
fi
if [[ ! -r "$ORIG" ]]; then
  echo "Error: origen '$ORIG' no es legible." >&2
  exit 3
fi


# 2) Destino existe, es directorio y escribible
if [[ ! -d "$DEST" ]]; then
  echo "Error: destino '$DEST' no existe o no es directorio." >&2
  exit 4
fi
if [[ ! -w "$DEST" ]]; then
  echo "Error: '$DEST' no es escribible." >&2
  exit 5
fi


# 3) Destino esta montado (no un directorio vacio)
if ! mountpoint -q "$DEST"; then
  echo "Error: '$DEST' no es un punto de montaje activo." >&2
  exit 6
fi


# --- nombre de archivo (YYYYMMDD) ---
FECHA="$(date +%Y%m%d)"         #formato ANSI YYYYMMDD
BASE="$(basename "$ORIG" | tr '/' '_' | tr -c '[:alnum:]_-' '_')"
SALIDA="${DEST}/${BASE}_bkp_${FECHA}.tar.gz"


# --- backup ---
# tar:
#  -c crear     -z comprimir gzip
#  -p preservar perms    -f archivo destino   -C cambia directorio
#  --xattrs  --acls preservan metadatos (si estan disponibles)
tar -czpf "$SALIDA" --xattrs  --acls  -C "$ORIG" .


# --- verificacion basica ---
if [[ -s "$SALIDA" ]]; then
  echo "OK: creado $SALIDA"
else
  echo "Error: archivo de salida vacio." >&2
  exit 7
fi
